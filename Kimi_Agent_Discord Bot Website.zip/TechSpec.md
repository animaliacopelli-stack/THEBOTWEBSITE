# Technical Specification

## Component Inventory

### shadcn/ui Components
- **Button**: For CTAs and interactive elements
- **Card**: For feature cards and pricing cards
- **Badge**: For plan labels
- **Separator**: For visual dividers

### Third-party Registry Components
None required - custom implementations preferred for unique design.

### Custom Components
1. **NebulaBackground**: WebGL shader background for Hero
2. **MagneticButton**: Button with magnetic cursor attraction
3. **FeatureCard**: 3D tilt card with glow effects
4. **PricingCard**: Glassmorphism pricing card
5. **CountUp**: Animated number counter
6. **ParticleStream**: Background particle system
7. **ScrollReveal**: Wrapper for scroll-triggered animations

## Animation Implementation Table

| Animation | Library | Implementation Approach | Complexity |
|-----------|---------|------------------------|------------|
| Hero Nebula Background | Three.js/React Three Fiber | Fragment shader with time uniform | High |
| Hero Text Reveal | GSAP | SplitType + staggered char animation | Medium |
| Magnetic Button | Custom Hook | Mouse position tracking + spring physics | Medium |
| Hero Image 3D Orbit | GSAP | Perspective transform + scroll trigger | Medium |
| Feature Card 3D Tilt | Custom + CSS | Mouse position → rotateX/Y transform | Medium |
| Feature Card Flip Entrance | GSAP ScrollTrigger | rotateX 90→0 with stagger | Medium |
| Timeline Path Draw | GSAP DrawSVGPlugin | stroke-dashoffset animation | Medium |
| Pricing Glass Effect | CSS | backdrop-filter + gradient border | Low |
| Stats Count Up | Custom Hook | requestAnimationFrame counter | Low |
| Particle Stream | Canvas API | RequestAnimationFrame particle loop | Medium |
| Footer Wave Border | CSS/SVG | Animated SVG stroke | Low |
| Smooth Scroll | Lenis | Integrated with GSAP ScrollTrigger | Low |

## Animation Library Choices

### GSAP (GreenSock Animation Platform)
**Rationale**: Industry-standard for complex web animations. Excellent performance, precise control, and robust scroll-triggering via ScrollTrigger.
- **Use for**: All scroll-triggered animations, timeline sequences, text reveals
- **Plugins**: ScrollTrigger, SplitText (or SplitType), DrawSVG (if available)

### React Three Fiber (@react-three/fiber)
**Rationale**: React-friendly wrapper for Three.js. Perfect for the hero shader background.
- **Use for**: Nebula background shader, 3D card effects

### Lenis
**Rationale**: Smooth scrolling is essential for the parallax effects to feel premium.
- **Use for**: Global smooth scroll damping

### Custom Hooks
**Rationale**: Simple physics-based interactions (magnetic buttons) are often lighter custom-built than importing a full library.
- **Use for**: Magnetic button effect, mouse tracking for card tilts

## Project File Structure

```
app/
├── src/
│   ├── components/
│   │   ├── ui/              # shadcn components
│   │   ├── NebulaBackground.tsx
│   │   ├── MagneticButton.tsx
│   │   ├── FeatureCard.tsx
│   │   ├── PricingCard.tsx
│   │   ├── CountUp.tsx
│   │   ├── ParticleStream.tsx
│   │   └── ScrollReveal.tsx
│   ├── sections/
│   │   ├── Hero.tsx
│   │   ├── Features.tsx
│   │   ├── HowItWorks.tsx
│   │   ├── Premium.tsx
│   │   ├── Stats.tsx
│   │   └── Footer.tsx
│   ├── hooks/
│   │   ├── useMousePosition.ts
│   │   ├── useMagneticEffect.ts
│   │   └── useCountUp.ts
│   ├── lib/
│   │   └── utils.ts
│   ├── App.tsx
│   ├── main.tsx
│   └── index.css
├── public/
│   └── images/              # Generated images
├── package.json
└── vite.config.ts
```

## Dependencies to Install

```bash
# Animation libraries
npm install gsap @gsap/react
npm install @studio-freight/lenis
npm install three @react-three/fiber @react-three/drei

# Utilities
npm install clsx tailwind-merge
npm install split-type  # Alternative to GSAP SplitText

# shadcn components
npx shadcn add button card badge separator
```

## Performance Optimization Strategy

1. **GPU Acceleration**: All animations use `transform` and `opacity` only
2. **Will-Change**: Applied to frequently animated elements (cards, numbers)
3. **Offscreen Rendering**: Hero shader runs on separate layer
4. **Lazy Loading**: Images below fold loaded with intersection observer
5. **Reduced Motion**: Full support for `prefers-reduced-motion`

## Responsive Breakpoints

- **Desktop**: 1200px+ (Full effects)
- **Tablet**: 768px - 1199px (Reduced parallax, simplified 3D)
- **Mobile**: < 768px (No WebGL background, simple fades)

## Color Variables (CSS)

```css
:root {
  --color-primary: #4c68ff;
  --color-secondary: #c07cff;
  --color-tertiary: #ff5e5e;
  --color-background: #0a0a0a;
  --color-surface: #141414;
  --color-text: #ffffff;
  --color-muted: #a0a0a0;
}
```
