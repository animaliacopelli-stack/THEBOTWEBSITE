import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Button } from '@/components/ui/button';
import { ArrowRight, Sparkles } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const Hero = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const headingRef = useRef<HTMLHeadingElement>(null);
  const subheadingRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Nebula background animation
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;
    let time = 0;

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    resize();
    window.addEventListener('resize', resize);

    const drawNebula = () => {
      time += 0.005;

      // Clear canvas
      ctx.fillStyle = '#0a0a0a';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Create gradient orbs
      const orbs = [
        { x: canvas.width * 0.3, y: canvas.height * 0.4, radius: 400, color: '#4c68ff', offset: 0 },
        { x: canvas.width * 0.7, y: canvas.height * 0.5, radius: 350, color: '#c07cff', offset: 2 },
        { x: canvas.width * 0.5, y: canvas.height * 0.3, radius: 300, color: '#4c68ff', offset: 4 },
      ];

      orbs.forEach((orb) => {
        const x = orb.x + Math.sin(time + orb.offset) * 50;
        const y = orb.y + Math.cos(time + orb.offset * 0.7) * 30;

        const gradient = ctx.createRadialGradient(x, y, 0, x, y, orb.radius);
        gradient.addColorStop(0, `${orb.color}40`);
        gradient.addColorStop(0.5, `${orb.color}15`);
        gradient.addColorStop(1, 'transparent');

        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, canvas.width, canvas.height);
      });

      animationId = requestAnimationFrame(drawNebula);
    };

    drawNebula();

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener('resize', resize);
    };
  }, []);

  // GSAP animations
  useEffect(() => {
    const ctx = gsap.context(() => {
      // Heading animation - split character reveal
      if (headingRef.current) {
        const text = headingRef.current.innerText;
        headingRef.current.innerHTML = text
          .split('')
          .map((char) => `<span class="inline-block">${char === ' ' ? '&nbsp;' : char}</span>`)
          .join('');

        gsap.fromTo(
          headingRef.current.querySelectorAll('span'),
          { y: '100%', opacity: 0 },
          {
            y: '0%',
            opacity: 1,
            duration: 0.8,
            stagger: 0.03,
            ease: 'expo.out',
            delay: 0.2,
          }
        );
      }

      // Subheading fade + blur
      gsap.fromTo(
        subheadingRef.current,
        { opacity: 0, filter: 'blur(10px)' },
        { opacity: 1, filter: 'blur(0px)', duration: 0.6, delay: 0.5, ease: 'power2.out' }
      );

      // CTA button pop
      gsap.fromTo(
        ctaRef.current,
        { scale: 0, opacity: 0 },
        { scale: 1, opacity: 1, duration: 0.5, delay: 0.7, ease: 'elastic.out(1, 0.5)' }
      );

      // Image 3D orbit entry
      gsap.fromTo(
        imageRef.current,
        { rotateY: 45, z: -500, opacity: 0 },
        { rotateY: 0, z: 0, opacity: 1, duration: 1.2, delay: 0.3, ease: 'power3.out' }
      );

      // Scroll-triggered parallax
      gsap.to(headingRef.current, {
        y: -100,
        opacity: 0,
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: '50% top',
          scrub: 1,
        },
      });

      gsap.to(imageRef.current, {
        rotateX: 20,
        scale: 0.9,
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: '50% top',
          scrub: 1,
        },
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20"
      style={{ perspective: '1000px' }}
    >
      {/* Nebula Background Canvas */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full"
        style={{ zIndex: -1 }}
      />

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Text Content */}
          <div className="text-center lg:text-left">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 mb-6">
              <Sparkles className="w-4 h-4 text-[#c07cff]" />
              <span className="text-sm text-[#a0a0a0]">The Ultimate Discord Bot</span>
            </div>

            <h1
              ref={headingRef}
              className="text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-bold font-['Poppins'] leading-tight mb-6 overflow-hidden"
            >
              Power Up Your{' '}
              <span className="text-gradient">Discord Server</span>
            </h1>

            <p
              ref={subheadingRef}
              className="text-lg sm:text-xl text-[#a0a0a0] mb-8 max-w-xl mx-auto lg:mx-0"
            >
              Powerful moderation, leveling, economy, and fun commands for your server. 
              Easy setup with <code className="text-[#4c68ff] bg-[#4c68ff]/10 px-2 py-0.5 rounded">/config</code> command.
            </p>

            <div ref={ctaRef} className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Button
                size="lg"
                className="bg-gradient-brand hover:opacity-90 text-white font-semibold px-8 py-6 rounded-xl text-lg transition-all duration-300 hover:scale-105 hover:shadow-xl hover:shadow-[#4c68ff]/30 group"
                onClick={() => window.open('https://discord.com/oauth2/authorize', '_blank')}
              >
                Add to Discord
                <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-white/20 text-white hover:bg-white/10 px-8 py-6 rounded-xl text-lg transition-all duration-300"
                onClick={() => document.querySelector('#features')?.scrollIntoView({ behavior: 'smooth' })}
              >
                Learn More
              </Button>
            </div>
          </div>

          {/* Hero Image */}
          <div
            ref={imageRef}
            className="relative"
            style={{ transformStyle: 'preserve-3d' }}
          >
            <div className="relative float-animation">
              {/* Glow effect behind image */}
              <div className="absolute inset-0 bg-gradient-brand opacity-30 blur-3xl rounded-3xl transform scale-110" />
              
              {/* Main image */}
              <img
                src="/images/hero-dashboard.jpg"
                alt="Discord Bot Dashboard"
                className="relative rounded-2xl shadow-2xl border border-white/10 w-full"
              />

              {/* Floating badges */}
              <div className="absolute -top-4 -right-4 px-4 py-2 bg-[#141414] rounded-xl border border-white/10 shadow-xl">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                  <span className="text-sm font-medium">Online</span>
                </div>
              </div>

              <div className="absolute -bottom-4 -left-4 px-4 py-3 bg-[#141414] rounded-xl border border-white/10 shadow-xl">
                <div className="text-2xl font-bold text-gradient">50K+</div>
                <div className="text-xs text-[#a0a0a0]">Active Servers</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom gradient fade */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-[#0a0a0a] to-transparent pointer-events-none" />
    </section>
  );
};

export default Hero;
