import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { UserPlus, Settings2, PartyPopper } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const steps = [
  {
    number: '01',
    title: 'Invite the Bot',
    description: 'Add the bot to your server with one click. No complicated setup required.',
    image: '/images/step1-invite.jpg',
    icon: UserPlus,
  },
  {
    number: '02',
    title: 'Run /config',
    description: 'Use the /config command to customize your server settings. Set up logging, welcome messages, auto-roles, and more.',
    image: '/images/step2-config.jpg',
    icon: Settings2,
  },
  {
    number: '03',
    title: 'Enjoy!',
    description: 'Start using all the features. Your server is now powered up and ready to go!',
    image: '/images/step3-enjoy.jpg',
    icon: PartyPopper,
  },
];

const HowItWorks = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const headingRef = useRef<HTMLDivElement>(null);
  const pathRef = useRef<SVGPathElement>(null);
  const stepsRef = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Heading animation
      gsap.fromTo(
        headingRef.current,
        { opacity: 0, y: 50 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: headingRef.current,
            start: 'top 80%',
          },
        }
      );

      // Path draw animation
      if (pathRef.current) {
        const pathLength = pathRef.current.getTotalLength();
        gsap.set(pathRef.current, {
          strokeDasharray: pathLength,
          strokeDashoffset: pathLength,
        });

        gsap.to(pathRef.current, {
          strokeDashoffset: 0,
          duration: 2,
          ease: 'power2.inOut',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 60%',
            end: 'bottom 80%',
            scrub: 1,
          },
        });
      }

      // Steps animation
      stepsRef.current.forEach((step, index) => {
        if (!step) return;

        const isEven = index % 2 === 0;
        gsap.fromTo(
          step,
          { x: isEven ? -50 : 50, opacity: 0 },
          {
            x: 0,
            opacity: 1,
            duration: 0.6,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: step,
              start: 'top 75%',
            },
          }
        );
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="how-it-works"
      className="relative py-24 sm:py-32 overflow-hidden"
    >
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#4c68ff]/5 to-transparent pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        {/* Heading */}
        <div ref={headingRef} className="text-center mb-16 sm:mb-24">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold font-['Poppins'] mb-6">
            Get Started in <span className="text-gradient">Minutes</span>
          </h2>
          <p className="text-lg text-[#a0a0a0] max-w-2xl mx-auto">
            Setting up the bot is quick and easy. Follow these simple steps to get started.
          </p>
        </div>

        {/* Timeline */}
        <div className="relative">
          {/* SVG Path - hidden on mobile */}
          <svg
            className="absolute left-1/2 top-0 h-full w-4 -translate-x-1/2 hidden lg:block"
            viewBox="0 0 4 100"
            preserveAspectRatio="none"
          >
            <path
              ref={pathRef}
              d="M 2 0 L 2 100"
              stroke="url(#gradient)"
              strokeWidth="0.5"
              fill="none"
              vectorEffect="non-scaling-stroke"
              style={{ height: '100%' }}
            />
            <defs>
              <linearGradient id="gradient" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#4c68ff" />
                <stop offset="50%" stopColor="#c07cff" />
                <stop offset="100%" stopColor="#4c68ff" />
              </linearGradient>
            </defs>
          </svg>

          {/* Steps */}
          <div className="space-y-16 lg:space-y-24">
            {steps.map((step, index) => {
              const Icon = step.icon;
              const isEven = index % 2 === 0;

              return (
                <div
                  key={step.number}
                  ref={(el) => { stepsRef.current[index] = el; }}
                  className={`relative flex flex-col lg:flex-row items-center gap-8 lg:gap-16 ${
                    isEven ? 'lg:flex-row' : 'lg:flex-row-reverse'
                  }`}
                >
                  {/* Content */}
                  <div className={`flex-1 text-center ${isEven ? 'lg:text-right' : 'lg:text-left'}`}>
                    <div className={`inline-flex items-center gap-3 mb-4 ${isEven ? 'lg:flex-row-reverse' : ''}`}>
                      <div className="w-12 h-12 rounded-xl bg-gradient-brand flex items-center justify-center">
                        <Icon className="w-6 h-6 text-white" />
                      </div>
                      <span className="text-5xl font-bold text-white/10 font-['Poppins']">
                        {step.number}
                      </span>
                    </div>
                    <h3 className="text-2xl sm:text-3xl font-bold font-['Poppins'] mb-4">
                      {step.title}
                    </h3>
                    <p className="text-[#a0a0a0] text-lg max-w-md mx-auto lg:mx-0">
                      {step.description}
                    </p>
                  </div>

                  {/* Center Node - hidden on mobile */}
                  <div className="hidden lg:flex absolute left-1/2 -translate-x-1/2 w-6 h-6 items-center justify-center">
                    <div className="w-4 h-4 rounded-full bg-gradient-brand" />
                    <div className="absolute w-8 h-8 rounded-full bg-[#4c68ff]/20 animate-ping" />
                  </div>

                  {/* Image */}
                  <div className="flex-1 w-full max-w-md lg:max-w-none">
                    <div className="relative group">
                      <div className="absolute inset-0 bg-gradient-brand opacity-20 blur-2xl rounded-2xl transform group-hover:scale-105 transition-transform duration-500" />
                      <img
                        src={step.image}
                        alt={step.title}
                        className="relative rounded-2xl border border-white/10 shadow-xl w-full transform group-hover:scale-[1.02] transition-transform duration-500"
                      />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;
