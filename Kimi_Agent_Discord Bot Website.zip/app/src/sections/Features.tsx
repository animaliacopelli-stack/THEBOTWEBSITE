import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import {
  Shield,
  TrendingUp,
  Coins,
  Ticket,
  Star,
  ClipboardList,
  Settings,
  Lock,
} from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface Feature {
  icon: React.ElementType;
  title: string;
  description: string;
  color: string;
}

const features: Feature[] = [
  {
    icon: Shield,
    title: 'Moderation',
    description: 'Keep your server safe with advanced moderation tools including ban, kick, mute, and warn commands.',
    color: '#ff5e5e',
  },
  {
    icon: TrendingUp,
    title: 'Leveling',
    description: 'Reward active members with XP and levels. Customizable level-up messages and roles.',
    color: '#4c68ff',
  },
  {
    icon: Coins,
    title: 'Economy',
    description: 'Create your own server economy with custom currency, daily rewards, and work commands.',
    color: '#c07cff',
  },
  {
    icon: Ticket,
    title: 'Tickets',
    description: 'Support your members with an easy-to-use ticket system and automatic transcripts.',
    color: '#4c68ff',
  },
  {
    icon: Star,
    title: 'Starboard',
    description: 'Highlight the best messages with star reactions. Customizable star threshold.',
    color: '#c07cff',
  },
  {
    icon: ClipboardList,
    title: 'Logging',
    description: 'Track everything that happens in your server with detailed logs and mod actions.',
    color: '#ff5e5e',
  },
  {
    icon: Settings,
    title: 'Auto Roles',
    description: 'Automatically assign roles to new members and bots when they join your server.',
    color: '#4c68ff',
  },
  {
    icon: Lock,
    title: 'Protection',
    description: 'Anti-raid and anti-spam protection to keep your server safe from attacks.',
    color: '#c07cff',
  },
];

const FeatureCard = ({ feature, index }: { feature: Feature; index: number }) => {
  const cardRef = useRef<HTMLDivElement>(null);
  const [transform, setTransform] = useState({ rotateX: 0, rotateY: 0 });
  const Icon = feature.icon;

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;
    const rotateX = (y - centerY) / 10;
    const rotateY = (centerX - x) / 10;
    setTransform({ rotateX, rotateY });
  };

  const handleMouseLeave = () => {
    setTransform({ rotateX: 0, rotateY: 0 });
  };

  return (
    <div
      ref={cardRef}
      className="feature-card group relative"
      style={{
        transform: `perspective(1000px) rotateX(${transform.rotateX}deg) rotateY(${transform.rotateY}deg)`,
        transition: 'transform 0.1s ease-out',
        animationDelay: `${index * 0.1}s`,
      }}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
    >
      {/* Glow effect */}
      <div
        className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500"
        style={{
          background: `radial-gradient(circle at 50% 50%, ${feature.color}20, transparent 70%)`,
        }}
      />

      {/* Card content */}
      <div className="relative p-6 sm:p-8 rounded-2xl bg-[#141414] border border-white/5 hover:border-white/20 transition-all duration-300 h-full">
        {/* Icon */}
        <div
          className="w-14 h-14 rounded-xl flex items-center justify-center mb-5 transition-transform duration-300 group-hover:scale-110"
          style={{ backgroundColor: `${feature.color}15` }}
        >
          <Icon className="w-7 h-7" style={{ color: feature.color }} />
        </div>

        {/* Text */}
        <h3 className="text-xl font-bold font-['Poppins'] mb-3 text-white group-hover:text-gradient transition-all duration-300">
          {feature.title}
        </h3>
        <p className="text-[#a0a0a0] text-sm leading-relaxed">
          {feature.description}
        </p>

        {/* Corner accent */}
        <div
          className="absolute top-0 right-0 w-20 h-20 opacity-0 group-hover:opacity-100 transition-opacity duration-500"
          style={{
            background: `linear-gradient(135deg, transparent 50%, ${feature.color}10 50%)`,
            borderRadius: '0 1rem 0 0',
          }}
        />
      </div>
    </div>
  );
};

const Features = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const headingRef = useRef<HTMLDivElement>(null);
  const gridRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Heading animation
      gsap.fromTo(
        headingRef.current,
        { opacity: 0, y: 50 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: headingRef.current,
            start: 'top 80%',
          },
        }
      );

      // Cards animation - 3D flip up
      const cards = gridRef.current?.querySelectorAll('.feature-card');
      if (cards) {
        gsap.fromTo(
          cards,
          { rotateX: 90, y: 100, opacity: 0 },
          {
            rotateX: 0,
            y: 0,
            opacity: 1,
            duration: 0.8,
            stagger: 0.1,
            ease: 'back.out(1.2)',
            scrollTrigger: {
              trigger: gridRef.current,
              start: 'top 75%',
            },
          }
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="features"
      className="relative py-24 sm:py-32"
      style={{ perspective: '2000px' }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Heading */}
        <div ref={headingRef} className="text-center mb-16 sm:mb-20">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold font-['Poppins'] mb-6">
            Everything You <span className="text-gradient">Need</span>
          </h2>
          <p className="text-lg text-[#a0a0a0] max-w-2xl mx-auto">
            Powerful features to enhance your Discord server. From moderation to fun commands, 
            we've got you covered.
          </p>
        </div>

        {/* Features Grid */}
        <div
          ref={gridRef}
          className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6"
          style={{ transformStyle: 'preserve-3d' }}
        >
          {features.map((feature, index) => (
            <FeatureCard key={feature.title} feature={feature} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;
