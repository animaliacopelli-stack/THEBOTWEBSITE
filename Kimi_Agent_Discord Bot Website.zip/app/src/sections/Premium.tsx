import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Button } from '@/components/ui/button';
import { Check, Sparkles, Zap, Crown } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const plans = [
  {
    name: 'Basic',
    price: 4.99,
    description: 'Essential features for small servers',
    icon: Sparkles,
    color: '#cd7f32',
    features: [
      'Basic moderation commands',
      'Leveling system',
      'Economy commands',
      'Welcome messages',
      'Auto roles',
      '5 ticket categories',
    ],
    popular: false,
  },
  {
    name: 'Pro',
    price: 9.99,
    description: 'Advanced features for growing communities',
    icon: Zap,
    color: '#c0c0c0',
    features: [
      'Everything in Basic',
      'Advanced moderation',
      'Custom commands',
      'Advanced logging',
      'Anti-raid protection',
      'Unlimited tickets',
      'Priority support',
    ],
    popular: true,
  },
  {
    name: 'Ultimate',
    price: 19.99,
    description: 'Everything for large servers',
    icon: Crown,
    color: '#ffd700',
    features: [
      'Everything in Pro',
      'White-label option',
      'Custom bot username',
      'Dedicated server',
      'API access',
      'Custom integrations',
      '24/7 priority support',
    ],
    popular: false,
  },
];

const PricingCard = ({ plan, index }: { plan: typeof plans[0]; index: number }) => {
  const cardRef = useRef<HTMLDivElement>(null);
  const [displayPrice, setDisplayPrice] = useState(0);
  const Icon = plan.icon;

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Price count up animation
      ScrollTrigger.create({
        trigger: cardRef.current,
        start: 'top 80%',
        onEnter: () => {
          gsap.to(
            { value: 0 },
            {
              value: plan.price,
              duration: 1,
              ease: 'power2.out',
              onUpdate: function () {
                setDisplayPrice(Number(this.targets()[0].value.toFixed(2)));
              },
            }
          );
        },
      });
    }, cardRef);

    return () => ctx.revert();
  }, [plan.price]);

  return (
    <div
      ref={cardRef}
      className={`pricing-card relative group ${plan.popular ? 'lg:-mt-4 lg:mb-4' : ''}`}
      style={{ animationDelay: `${index * 0.1}s` }}
    >
      {/* Popular badge */}
      {plan.popular && (
        <div className="absolute -top-4 left-1/2 -translate-x-1/2 z-10">
          <div className="px-4 py-1 bg-gradient-brand rounded-full text-sm font-semibold">
            Most Popular
          </div>
        </div>
      )}

      {/* Card */}
      <div
        className={`relative h-full p-6 sm:p-8 rounded-2xl backdrop-blur-xl transition-all duration-500 ${
          plan.popular
            ? 'bg-[#141414]/90 border-2 border-[#4c68ff]/50 scale-105'
            : 'bg-[#141414]/70 border border-white/10 hover:border-white/20'
        }`}
      >
        {/* Glass reflection effect */}
        <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-white/5 to-transparent pointer-events-none" />

        {/* Header */}
        <div className="relative text-center mb-6">
          <div
            className="w-16 h-16 rounded-2xl mx-auto mb-4 flex items-center justify-center"
            style={{ backgroundColor: `${plan.color}20` }}
          >
            <Icon className="w-8 h-8" style={{ color: plan.color }} />
          </div>
          <h3 className="text-2xl font-bold font-['Poppins'] mb-2">{plan.name}</h3>
          <p className="text-sm text-[#a0a0a0]">{plan.description}</p>
        </div>

        {/* Price */}
        <div className="relative text-center mb-8">
          <div className="flex items-baseline justify-center gap-1">
            <span className="text-2xl text-[#a0a0a0]">$</span>
            <span className="text-5xl font-bold font-['Poppins']">{displayPrice.toFixed(2)}</span>
          </div>
          <span className="text-[#a0a0a0]">/month</span>
        </div>

        {/* Features */}
        <ul className="relative space-y-3 mb-8">
          {plan.features.map((feature, i) => (
            <li key={i} className="flex items-center gap-3">
              <div
                className="w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0"
                style={{ backgroundColor: `${plan.color}20` }}
              >
                <Check className="w-3 h-3" style={{ color: plan.color }} />
              </div>
              <span className="text-sm text-[#a0a0a0]">{feature}</span>
            </li>
          ))}
        </ul>

        {/* CTA Button */}
        <Button
          className={`w-full py-6 rounded-xl font-semibold transition-all duration-300 ${
            plan.popular
              ? 'bg-gradient-brand hover:opacity-90 text-white hover:shadow-lg hover:shadow-[#4c68ff]/30'
              : 'bg-white/5 hover:bg-white/10 text-white border border-white/10'
          }`}
          onClick={() => window.open('https://discord.com/oauth2/authorize', '_blank')}
        >
          Get Started
        </Button>
      </div>
    </div>
  );
};

const Premium = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const headingRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Heading animation
      gsap.fromTo(
        headingRef.current,
        { opacity: 0, y: 50 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: headingRef.current,
            start: 'top 80%',
          },
        }
      );

      // Cards animation
      const cards = cardsRef.current?.querySelectorAll('.pricing-card');
      if (cards) {
        gsap.fromTo(
          cards,
          { scale: 0.5, opacity: 0 },
          {
            scale: 1,
            opacity: 1,
            duration: 0.8,
            stagger: 0.1,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: cardsRef.current,
              start: 'top 75%',
            },
          }
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="premium"
      className="relative py-24 sm:py-32 overflow-hidden"
    >
      {/* Background glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-gradient-brand opacity-10 blur-[150px] rounded-full pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        {/* Heading */}
        <div ref={headingRef} className="text-center mb-16 sm:mb-20">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold font-['Poppins'] mb-6">
            Upgrade Your <span className="text-gradient">Experience</span>
          </h2>
          <p className="text-lg text-[#a0a0a0] max-w-2xl mx-auto">
            Choose the plan that fits your server. All plans include a 7-day free trial.
          </p>
        </div>

        {/* Pricing Cards */}
        <div
          ref={cardsRef}
          className="grid md:grid-cols-3 gap-6 lg:gap-8 items-center"
        >
          {plans.map((plan, index) => (
            <PricingCard key={plan.name} plan={plan} index={index} />
          ))}
        </div>

        {/* Trust badges */}
        <div className="mt-16 flex flex-wrap justify-center gap-6 text-sm text-[#a0a0a0]">
          <div className="flex items-center gap-2">
            <Check className="w-4 h-4 text-green-500" />
            <span>7-day free trial</span>
          </div>
          <div className="flex items-center gap-2">
            <Check className="w-4 h-4 text-green-500" />
            <span>Cancel anytime</span>
          </div>
          <div className="flex items-center gap-2">
            <Check className="w-4 h-4 text-green-500" />
            <span>Secure payment</span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Premium;
